<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "test1";

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) 
{
	die("No hay conexión: ".mysqli_connect_error());
}

$nombre = $_POST["txtusuario"];
$pass = $_POST["txtpassword"];

$query = mysqli_query($conn,"SELECT * FROM login WHERE usuario = '".$nombre."' and password = '".$pass."'");
$nr = mysqli_num_rows($query);

if($nr == 1)
{
	//header("Location: pagina.html")
	
	echo "Bienvenido: " .$nombre;
	
}
else if ($nr == 0) 
{
	
	// "No ingreso"; 
	echo "<script> alert('usuario y/o contraseña incorrecto');window.location= 'login.html' </script>";
}
	


?>