<?php

include("conexion.php");
include("diseño.html");

?>



